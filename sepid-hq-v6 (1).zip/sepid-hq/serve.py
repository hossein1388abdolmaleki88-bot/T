"""Run from any working directory: python serve.py [port]."""
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import sys

port = int(sys.argv[1]) if len(sys.argv) > 1 else 3000
root = Path(__file__).resolve().parent
handler = partial(SimpleHTTPRequestHandler, directory=str(root))
print(f'Sepid: http://localhost:{port}/index.html')
print(f'Isolated 3D scene: http://localhost:{port}/scene.html')
try:
    ThreadingHTTPServer(('0.0.0.0', port), handler).serve_forever()
except KeyboardInterrupt:
    print('\nStopped.')
