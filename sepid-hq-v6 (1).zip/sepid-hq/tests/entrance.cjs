const {chromium}=require('playwright');
const assert=require('node:assert/strict');
const fs=require('node:fs');
(async()=>{
 const base=process.env.BASE_URL || 'http://localhost:3000';
 const browser=await chromium.launch({args:['--no-sandbox','--enable-webgl','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
 const page=await browser.newPage({viewport:{width:1440,height:1000}});
 const errors=[];
 page.on('pageerror',e=>errors.push(e.message));
 page.on('console',m=>{if(m.type()==='error')errors.push(m.text())});
 // Catch the actual first rendered frame, without replay or synthetic render times.
 await page.addInitScript(()=>{
   document.addEventListener('toothready',event=>{
     const v=event.detail;
     const render=v.render.bind(v);
     let first=true;
     v.render=(time,dt,still)=>{
       render(time,dt,still);
       if(first){first=false;window.firstEntrance={...v.getStats(),rotation:v.orbits.entries[0].group.rotation.z};}
     };
   },true);
 });
 const samples=[];
 for(let i=0;i<2;i++){
   if(i)await page.reload();else await page.goto(base);
   await page.waitForFunction(()=>window.firstEntrance && window.sepidTooth?.initialized);
   const initial=await page.evaluate(()=>window.firstEntrance);
   assert.ok(initial.introScale>2.5,'actual initial frame starts oversized');
   await page.waitForFunction(()=>window.sepidTooth.orbits.introProgress>.25);
   await page.evaluate(()=>window.sepidTooth.pause());
   await page.waitForFunction(()=>window.sepidTooth.controller.raf===0);
   const middle=await page.evaluate(()=>({...window.sepidTooth.getStats(),rotation:window.sepidTooth.orbits.entries[0].group.rotation.z}));
   assert.ok(middle.introScale>1 && middle.introScale<initial.introScale);
   assert.notEqual(middle.rotation,initial.rotation);
   await page.waitForTimeout(200);
   assert.equal(await page.evaluate(()=>window.sepidTooth.orbits.scale.x),middle.introScale,'pause freezes arrival');
   await page.evaluate(()=>window.sepidTooth.resume());
   await page.waitForFunction(()=>window.sepidTooth.orbits.introProgress===1,null,{timeout:120000});
   const final=await page.evaluate(()=>{window.sepidTooth.pause();return window.sepidTooth.getStats()});
   assert.equal(final.introScale,1);
   samples.push({initial,middle,final});
 }
 await page.emulateMedia({reducedMotion:'reduce'});
 await page.reload();await page.waitForFunction(()=>window.firstEntrance);
 assert.equal(await page.evaluate(()=>window.firstEntrance.introScale),1);
 assert.deepEqual(errors,[]);
 fs.writeFileSync('tests/entrance-report.json',JSON.stringify({actualInitialFrames:true,refreshRestarts:true,pauseFreezesEntrance:true,reducedSkipsEntrance:true,samples,errors},null,2));
 await browser.close();console.log('Real first-frame scale, refresh, rotation, pause, settling and reduced motion passed.');
})().catch(e=>{console.error(e);process.exit(1)});
