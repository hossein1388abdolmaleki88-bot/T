const { chromium } = require('playwright');
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');

(async () => {
  const browser = await chromium.launch({ args: ['--no-sandbox', '--enable-webgl', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  const page = await browser.newPage();
  page.setDefaultTimeout(120000);
  await page.emulateMedia({reducedMotion:'reduce'});
  const errors=[];
  const external=[];
  page.on('pageerror',error=>errors.push(error.message));
  page.on('console',message=>{if(message.type()==='error')errors.push(message.text());});
  const base=process.env.BASE_URL || 'http://localhost:3000';
  page.on('request',request=>{if(!request.url().startsWith(base))external.push(request.url());});
  const report={viewports:[],errors,external,notes:'Chromium software-WebGL; layout captures use reduced motion. Particle/pause are tested with animation enabled; entrance has a separate actual-frame test. Not physical-device FPS certification.'};
  const shots=path.join(__dirname,'screenshots');
  fs.mkdirSync(shots,{recursive:true});
  for(const [width,height] of [[360,640],[360,800],[393,851],[412,915],[320,640],[1440,1000]]) {
    await page.evaluate(()=>window.sepidTooth?.dispose());
    await page.setViewportSize({width,height});
    await page.goto(base+'/');
    await page.waitForFunction(()=>window.sepidTooth?.initialized,null,{timeout:120000});
    await page.waitForFunction(()=>window.sepidTooth.orbits.introProgress===1,null,{timeout:120000});
    await page.evaluate(()=>window.sepidTooth.pause());
    await page.waitForTimeout(150);
    const layout=await page.evaluate(()=>{
      const box=document.querySelector('.tooth-view').getBoundingClientRect();
      return {overflow:document.documentElement.scrollWidth>innerWidth,heroHeight:document.querySelector('.hero').offsetHeight,
        canvas:{width:box.width,height:box.height,left:box.left,top:box.top},stats:window.sepidTooth.getStats()};
    });
    assert.equal(layout.overflow,false,`horizontal overflow at ${width}`);
    assert.ok(layout.stats.vertexCount>20000);
    assert.ok(layout.stats.depthTest);
    report.viewports.push({width,height,...layout});
    if(width===393 || width===1440)await page.screenshot({path:path.join(shots,`site-${width}.png`)});
  }
  // Prove that curve samples lie both in front of and behind the closed mesh.
  report.occlusion=await page.evaluate(async()=>{
    const THREE=await import('/vendor/three.module.js');
    const view=window.sepidTooth;
    view.scene.updateMatrixWorld(true);view.camera.updateMatrixWorld(true);
    let occluded=0,visible=0;
    const ray=new THREE.Raycaster();
    for(const orbit of view.orbits.entries) {
      for(let i=0;i<120;i++) {
        const local=orbit.particles[0].curve.getPoint(i/120);
        const world=orbit.group.localToWorld(local);
        const direction=world.clone().sub(view.camera.position);
        const distance=direction.length();
        ray.set(view.camera.position,direction.normalize());
        const hits=ray.intersectObject(view.tooth.mesh);
        if(hits.length && hits[0].distance<distance-.005)occluded++;else visible++;
      }
    }
    return {occluded,visible};
  });
  assert.ok(report.occlusion.occluded>0 && report.occlusion.visible>0);
  await page.emulateMedia({reducedMotion:'no-preference'});
  const before=await page.evaluate(()=>window.sepidTooth.orbits.entries[0].particles[0].position.toArray());
  await page.evaluate(()=>window.sepidTooth.resume());
  await page.waitForTimeout(750);
  const after=await page.evaluate(()=>window.sepidTooth.orbits.entries[0].particles[0].position.toArray());
  assert.notDeepEqual(before,after);
  report.particleMoves=true;
  await page.waitForFunction(()=>window.sepidTooth.orbits.introProgress===1,null,{timeout:120000});
    await page.evaluate(()=>window.sepidTooth.pause());
  await page.waitForTimeout(800);
  await page.waitForFunction(()=>window.sepidTooth.controller.raf===0);
  const count=await page.evaluate(()=>window.sepidTooth.renderCount);
  await page.waitForTimeout(350);
  assert.equal(await page.evaluate(()=>window.sepidTooth.renderCount),count);
  report.pauseStopsLoop=true;
  await page.locator('header [data-book]').click();
  await page.locator('#name').fill('تست');
  await page.locator('#date').fill('2028-12-20');
  await page.locator('#booking-form .submit').click();
  assert.ok(await page.locator('#confirmation').isVisible());
  await page.keyboard.press('Escape');
  report.bookingDemo=true;
  await page.emulateMedia({reducedMotion:'reduce'});
  await page.reload();
  await page.waitForFunction(()=>window.sepidTooth?.initialized);
  await page.waitForTimeout(800);
  await page.waitForFunction(()=>window.sepidTooth.controller.raf===0);
  const reducedCount=await page.evaluate(()=>window.sepidTooth.renderCount);
  await page.waitForTimeout(350);
  assert.equal(await page.evaluate(()=>window.sepidTooth.renderCount),reducedCount);
  report.reducedMotionStopsLoop=true;
  await page.emulateMedia({reducedMotion:'reduce'});
  await page.goto(base+'/scene.html');
  await page.waitForFunction(()=>window.sepidTooth?.initialized);
  await page.waitForFunction(()=>window.sepidTooth.orbits.introProgress===1,null,{timeout:120000});
    await page.evaluate(()=>window.sepidTooth.pause());
  await page.waitForTimeout(150);
  await page.screenshot({path:path.join(shots,'scene-desktop.png')});
  assert.deepEqual(errors,[]);
  assert.deepEqual(external,[]);
  fs.writeFileSync(path.join(__dirname,'report.json'),JSON.stringify(report,null,2));
  console.log(JSON.stringify(report,null,2));
  await browser.close();
})().catch(error=>{console.error(error);process.exit(1);});
