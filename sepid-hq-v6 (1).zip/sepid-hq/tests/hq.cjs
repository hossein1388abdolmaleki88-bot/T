const {chromium}=require('playwright');const assert=require('node:assert/strict');const fs=require('node:fs');
(async()=>{
 const b=await chromium.launch({args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
 const p=await b.newPage({viewport:{width:1568,height:1000}});const errors=[];p.on('pageerror',e=>errors.push(e.message));p.on('console',m=>{if(m.type()==='error')errors.push(m.text())});
 const base=process.env.BASE_URL||'http://localhost:3000';await p.goto(base);await p.waitForFunction(()=>window.sepidTooth?.initialized);
 await p.evaluate(()=>{const v=window.sepidTooth;v.pause();v.controller.time=1.6;v.render(1.6,0,true)});await p.waitForTimeout(300);
 const stats=await p.evaluate(()=>window.sepidTooth.getStats());assert.ok(stats.pixelRatio>=2);assert.ok(stats.antialias);assert.ok(stats.vertexCount>70000);
 // Adaptive performance cannot degrade image resolution below 2x.
 const floor=await p.evaluate(()=>{const v=window.sepidTooth;for(let i=0;i<20;i++){v.lastQualityChange=0;v.adapt(10)}return v.pixelRatio});assert.ok(floor>=2);
 await p.locator('#services').scrollIntoViewIfNeeded();await p.waitForTimeout(200);
 // Unpause only border decoration; keep software WebGL frozen for this isolated test.
 await p.evaluate(()=>document.documentElement.dataset.sceneMotion='running');
 const read=()=>p.locator('.service-border .border-head').evaluateAll(nodes=>nodes.map(n=>({offset:getComputedStyle(n).strokeDashoffset,duration:getComputedStyle(n).animationDuration,state:getComputedStyle(n).animationPlayState,viewBox:n.ownerSVGElement.getAttribute('viewBox')})));
 const before=await read();await p.waitForTimeout(700);const after=await read();console.log({before,after});
 assert.equal(before.length,4);assert.ok(after.every(n=>Number.isFinite(parseFloat(n.offset)) && Math.abs(parseFloat(n.offset)%1000)>1),'smooth numeric interpolation, not discrete jumps');assert.notDeepEqual(before.map(n=>n.offset),after.map(n=>n.offset),'border must travel');
 await p.screenshot({path:'tests/screenshots/hq-cards.png'});
 await p.emulateMedia({reducedMotion:'reduce'});await p.waitForTimeout(150);const reducedBefore=await read();await p.waitForTimeout(250);assert.deepEqual(await read(),reducedBefore);
 await p.setViewportSize({width:360,height:800});await p.goto(base);await p.waitForFunction(()=>window.sepidTooth?.initialized);await p.waitForTimeout(200);
 const mobile=await p.evaluate(()=>({stats:window.sepidTooth.getStats(),overflow:document.documentElement.scrollWidth>innerWidth}));assert.ok(mobile.stats.pixelRatio>=2);assert.equal(mobile.overflow,false);
 await p.screenshot({path:'tests/screenshots/hq-mobile.png'});assert.deepEqual(errors,[]);
 fs.writeFileSync('tests/hq-report.json',JSON.stringify({stats,qualityFloor:floor,mobile,borderMoves:true,reducedBorderStatic:true,before,after,errors},null,2));await b.close();
})().catch(e=>{console.error(e);process.exit(1)});
