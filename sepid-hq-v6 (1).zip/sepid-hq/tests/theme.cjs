const {chromium}=require('playwright');
const assert=require('node:assert/strict');const fs=require('node:fs');
(async()=>{
 const base=process.env.BASE_URL || 'http://localhost:3000';
 const b=await chromium.launch({args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
 const p=await b.newPage({reducedMotion:'reduce'});p.setDefaultTimeout(120000);const errors=[];p.on('pageerror',e=>errors.push(e.message));
 p.on('console',m=>{if(m.type()==='error')errors.push(m.text())});const report={viewports:[],sections:[],errors};
 for(const [width,height] of [[768,1024],[1024,768],[1568,881]]){
  await p.setViewportSize({width,height});await p.goto(base);await p.waitForFunction(()=>window.sepidTooth?.initialized);
  await p.waitForTimeout(200);
  const state=await p.evaluate(()=>({overflow:document.documentElement.scrollWidth>innerWidth,
   titleColor:getComputedStyle(document.querySelector('h1')).color,
   enamel:window.sepidTooth.tooth.mesh.material.color.getHexString(),
   stoneLoaded:!!window.sepidTooth.platform.children[0].material.map.image,
   roughness:window.sepidTooth.tooth.mesh.material.roughness,
   buttons:[...document.querySelectorAll('.hero-actions .btn')].map(x=>({background:getComputedStyle(x).background,color:getComputedStyle(x).color}))}));
  assert.equal(state.overflow,false);assert.equal(state.enamel,'fafcff');assert.ok(state.stoneLoaded);assert.ok(state.roughness<.1);
  report.viewports.push({width,height,...state});
 }
 // This is an actual live-rendered site screenshot, not the selected mockup.
 await p.screenshot({path:'tests/screenshots/ice-desktop.png'});
 for(const id of ['services','journey','anatomy','philosophy','comparison','timeline','metrics','faq','booking']){
  if(!await p.locator('#'+id).count())continue;
  await p.locator('#'+id).scrollIntoViewIfNeeded();await p.waitForTimeout(100);
  report.sections.push(await p.locator('#'+id).evaluate(x=>({id:x.id,background:getComputedStyle(x).background,color:getComputedStyle(x).color})));
  if(['services','faq'].includes(id))await p.screenshot({path:`tests/screenshots/${id}-desktop.png`});
 }
 await p.locator('#faq details').first().locator('summary').click();assert.equal(await p.locator('#faq details').first().getAttribute('open'),'');
 await p.locator('#compare-range').scrollIntoViewIfNeeded();await p.locator('#compare-range').fill('72');
 await p.locator('#compare-range').dispatchEvent('input');assert.equal(await p.locator('#compare-range').inputValue(),'72');
 await p.locator('#services [data-service]').first().click();assert.ok(await p.locator('#booking-dialog').isVisible());
 await p.screenshot({path:'tests/screenshots/booking-dialog.png'});await p.keyboard.press('Escape');
 report.faq=true;report.comparison=true;report.serviceBooking=true;assert.deepEqual(errors,[]);
 fs.writeFileSync('tests/theme-report.json',JSON.stringify(report,null,2));await b.close();console.log('Theme, tablet, selected-reference viewport, FAQ, comparison and service booking passed.');
})().catch(e=>{console.error(e);process.exit(1)});
