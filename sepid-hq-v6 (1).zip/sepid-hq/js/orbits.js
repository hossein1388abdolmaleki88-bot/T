import * as THREE from '../vendor/three.module.js';

const TAU = Math.PI * 2;
const clamp = n => Math.max(0, Math.min(1, n));
const easeOutCubic = t => 1 - Math.pow(1 - clamp(t), 3);

class OrbitalCurve extends THREE.Curve {
  constructor(rx, ry, phase) {
    super();
    this.rx = rx;
    this.ry = ry;
    this.phase = phase;
  }
  getPoint(t, target = new THREE.Vector3()) {
    const a = t * TAU;
    return target.set(
      this.rx * Math.cos(a),
      this.ry * Math.sin(a),
      .035 * Math.sin(a * 3 + this.phase)
    );
  }
}

// The bright filament and its soft envelope are actual tubes in world space.
// Both use the same depth buffer as the opaque tooth: never a screen overlay.
const lineVertex = `
  varying float vProgress;
  varying float vDepth;
  varying vec3 vNormal;
  varying vec3 vView;
  varying vec2 vNdc;
  void main() {
    vProgress = uv.x;
    vec4 view = modelViewMatrix * vec4(position, 1.);
    vDepth = view.z;
    vNormal = normalize(normalMatrix * normal);
    vView = normalize(-view.xyz);
    vec4 clip = projectionMatrix * view;
    vNdc = clip.xy / clip.w;
    gl_Position = clip;
  }
`;

const lineFragment = `
  uniform float uTime, uPhase, uSpeed, uOpacity, uGlow;
  uniform float uCameraDistance, uEntrance, uHalo, uSecond;
  uniform vec3 uColor, uHotColor;
  varying float vProgress, vDepth;
  varying vec3 vNormal, vView;
  varying vec2 vNdc;

  float pulse(float p, float head) {
    // Wrapped Gaussian: smooth on both sides of the head and around the seam.
    float d = fract(p - head + .5) - .5;
    float tail = fract(p - head + .565) - .5;
    return exp(-d*d / .0018) + .28 * exp(-tail*tail / .009);
  }
  void main() {
    float head = fract(uTime * uSpeed + uPhase);
    float shine = clamp(pulse(vProgress, head) + uSecond * .68 * pulse(vProgress, fract(head + .5)), 0., 1.);
    float wave = .5 + .5 * sin(vProgress * 12.56637 + uPhase * 9. - uTime * .15);
    float front = mix(.72, 1., smoothstep(-1.7, 1.7, vDepth + uCameraDistance));
    float opacity = (uOpacity * (.66 + .25 * wave) + shine * uGlow) * front;
    float specular = pow(max(dot(normalize(vNormal), normalize(vec3(-.5,.7,.6))),0.),2.);
    vec3 metal = mix(uColor * .72, uHotColor, specular * .9);
    vec3 color = mix(metal, uHotColor, shine * .85);
    if (uHalo > .5) {
      float softEdge = pow(max(dot(normalize(vNormal), normalize(vView)), 0.), 1.65);
      opacity = (.02 + shine * .17) * softEdge;
    }
    // Oversized entrance arcs gently leave the camera bounds, without hard cuts.
    float cameraEdge = 1. - max(abs(vNdc.x), abs(vNdc.y));
    opacity *= smoothstep(0., .055, cameraEdge) * uEntrance;
    gl_FragColor = vec4(color, clamp(opacity, 0., .98));
    #include <colorspace_fragment>
  }
`;

export class OrbitLine extends THREE.Mesh {
  constructor(curve, config, index, mobile, particleCount) {
    const segments = mobile ? 360 : 560;
    const uniforms = {
      uTime: { value: 0 },
      uPhase: { value: index * .213 },
      uSpeed: { value: config.particleSpeed / TAU * (1 + index * .13) },
      uColor: { value: new THREE.Color(config.orbitColor) },
      uHotColor: { value: new THREE.Color('#fff7df') },
      uOpacity: { value: config.lineOpacity },
      uGlow: { value: config.lineGlow },
      uCameraDistance: { value: config.cameraDistance },
      uEntrance: { value: 1 },
      uHalo: { value: 0 },
      uSecond: { value: particleCount > 1 ? 1 : 0 }
    };
    const material = new THREE.ShaderMaterial({
      uniforms,
      vertexShader: lineVertex,
      fragmentShader: lineFragment,
      transparent: true,
      depthTest: true,
      depthWrite: false,
      toneMapped: false
    });
    super(new THREE.TubeGeometry(curve, segments, config.lineWidth, 12, true), material);
    this.renderOrder = 2;
    this.frustumCulled = false;

    const haloUniforms = { ...uniforms, uHalo: { value: 1 } };
    const haloMaterial = new THREE.ShaderMaterial({
      uniforms: haloUniforms,
      vertexShader: lineVertex,
      fragmentShader: lineFragment,
      transparent: true,
      depthWrite: false,
      depthTest: true,
      toneMapped: false,
      blending: THREE.AdditiveBlending
    });
    this.halo = new THREE.Mesh(
      new THREE.TubeGeometry(curve, segments, config.lineWidth * 3.3, 10, true),
      haloMaterial
    );
    this.halo.frustumCulled = false;
    this.halo.renderOrder = 3;
    this.add(this.halo);
  }

  update(time, cameraDistance, entrance) {
    // Shared uniform objects also update the halo without a second write.
    const uniforms = this.material.uniforms;
    uniforms.uTime.value = time;
    uniforms.uCameraDistance.value = cameraDistance;
    uniforms.uEntrance.value = entrance;
  }
}

export class OrbitParticle extends THREE.Group {
  constructor(config, curve, index, orbitIndex) {
    super();
    this.curve = curve;
    this.phase = (orbitIndex * .213 + index * .5) % 1;
    this.speed = config.particleSpeed / TAU * (1 + orbitIndex * .13);
    const radius = index ? .030 : .035;
    const core = new THREE.Mesh(
      new THREE.SphereGeometry(radius, 24, 16),
      new THREE.MeshPhysicalMaterial({
        color: '#fff3d5',
        emissive: '#ffe7b3',
        emissiveIntensity: .6,
        roughness: .18,
        clearcoat: .7,
        clearcoatRoughness: .16,
        metalness: 0,
        depthTest: true
      })
    );
    this.add(core);
    const glow = new THREE.Mesh(
      new THREE.SphereGeometry(radius * 3.8, 20, 14),
      new THREE.ShaderMaterial({
        uniforms: {
          uGlow: { value: config.bloomIntensity },
          uEntrance: { value: 1 },
          uColor: { value: new THREE.Color('#ffefd0') }
        },
        vertexShader: `
          varying vec3 vNormal; varying vec3 vView;
          void main() {
            vec4 p = modelViewMatrix * vec4(position, 1.);
            vNormal = normalize(normalMatrix * normal);
            vView = normalize(-p.xyz);
            gl_Position = projectionMatrix * p;
          }`,
        fragmentShader: `
          varying vec3 vNormal; varying vec3 vView;
          uniform float uGlow, uEntrance; uniform vec3 uColor;
          void main() {
            float soft = pow(max(dot(normalize(vNormal), normalize(vView)), 0.), 2.8);
            gl_FragColor = vec4(uColor, soft * uGlow * uEntrance);
            #include <colorspace_fragment>
          }`,
        transparent: true,
        depthWrite: false,
        depthTest: true,
        toneMapped: false,
        blending: THREE.AdditiveBlending
      })
    );
    glow.renderOrder = 4;
    this.glow = glow;
    this.add(glow);
  }
  update(time, entrance) {
    this.curve.getPoint((this.phase + time * this.speed) % 1, this.position);
    this.glow.material.uniforms.uEntrance.value = entrance;
  }
}

export class OrbitSystem extends THREE.Group {
  constructor(config, mobile) {
    super();
    this.config = config;
    this.entries = [];
    this.introStart = 0;
    this.introProgress = config.introEnabled ? 0 : 1;
    const tilts = [
      [-.83, .32, -.40], [.72, -.24, .51],
      [1.14, .36, -.13], [.20, -.45, .58],
      [-.56, .38, 1.03], [.9, -.5, -.7], [.5, .2, .2], [.3, .9, -.3]
    ];
    for (let i = 0; i < config.orbitCount; i++) {
      const group = new THREE.Group();
      const curve = new OrbitalCurve(
        config.orbitRadius * (1 + (i % 3) * .015),
        config.orbitRadius * (.57 + (i % 2) * .10), i
      );
      const count = Math.floor(config.particleCount / config.orbitCount) +
        (i < config.particleCount % config.orbitCount ? 1 : 0);
      const line = new OrbitLine(curve, config, i, mobile, count);
      group.add(line);
      const particles = [];
      for (let j = 0; j < count; j++) {
        const particle = new OrbitParticle(config, curve, j, i);
        group.add(particle);
        particles.push(particle);
      }
      const tilt = tilts[i].map(n => n * config.orbitTilt);
      group.rotation.set(...tilt);
      group.position.y = .10 + (i % 2) * .06;
      this.add(group);
      this.entries.push({ group, line, particles, tilt, index: i });
    }
  }

  replay(time) { this.introStart = time; this.introProgress = 0; }

  update(time, { reduced = false, cameraDistance = 14.4 } = {}) {
    const config = this.config;
    const skip = reduced || !config.introEnabled || !config.autoAnimate;
    if (skip) this.introStart = time - config.introDuration;
    const progress = skip ? 1 : clamp((time - this.introStart) / Math.max(.1, config.introDuration));
    this.introProgress = progress;
    const ease = easeOutCubic(progress);
    const remaining = 1 - ease;
    const scale = 1 + (config.introScale - 1) * remaining;
    // Actual 3D transformations: not a CSS scale or a pre-rendered clip.
    this.scale.setScalar(scale);
    this.rotation.set(.24 * remaining, .72 * remaining, -.32 * remaining);
    const entrance = .38 + .62 * ease;
    for (const orbit of this.entries) {
      const { group, tilt, index, line, particles } = orbit;
      const direction = index % 2 ? -1 : 1;
      group.rotation.set(
        tilt[0] + Math.sin(time * .06 + index) * .035 + direction * .2 * remaining,
        tilt[1] + time * config.orbitSpeed * (index % 2 ? -.42 : .36),
        tilt[2] + Math.sin(time * .04 + index * 2) * .022 + direction * config.introSpin * remaining
      );
      line.update(time, cameraDistance, entrance);
      particles.forEach(particle => particle.update(time, entrance));
    }
  }
}
