// All values are in world units / radians / seconds. No CDN or runtime build.
export const DEFAULTS = {
  toothScale: 1,
  toothPosition: [0, 0.02, 0],
  toothRotation: [0, -0.025, 0],
  toothRoughness: 0.075,
  enamelColor: '#fafcff',
  translucency: 0,
  highlightIntensity: 1.0,
  floatAmplitude: 0.016,
  platformScale: 1,
  platformRadius: 2.1,
  platformTop: -1.85,
  platformHeight: 0.34,
  platformColor: '#edf3ff',
  backgroundColor: '#f6fafd',
  transparentBackground: true,
  orbitCount: 4,
  orbitRadius: 2.25,
  orbitTilt: 1,
  orbitSpeed: 0.075,
  particleCount: 8,
  particleSpeed: 0.60,
  lineOpacity: 0.92,
  lineGlow: 0.40,
  lineWidth: 0.0105,
  orbitColor: '#a3977d',
  bloomIntensity: 0.35, // Local depth-tested halo only; no full-screen bloom pass.
  introEnabled: true,
  introDuration: 1.35,
  introScale: 2.65,
  introSpin: 1.9,
  keyLightIntensity: 2.15,
  fillLightIntensity: 0.12,
  ambientIntensity: 0.36,
  cameraFov: 20,
  cameraDistance: 14.4,
  cameraTarget: [0, -0.26, 0],
  cameraHeight: -0.2,
  exposure: 1.02,
  maxPixelRatio: 3.0,
  mobilePixelRatio: 2.5,
  minPixelRatio: 2.0,
  shadowMapSize: 2048,
  interactionStrength: 0.075,
  autoAnimate: true,
  debug: false
};

export function makeConfig(overrides = {}) {
  const c = { ...DEFAULTS, ...overrides };
  c.orbitCount = Math.min(8, Math.max(0, Math.round(c.orbitCount)));
  c.particleCount = Math.min(18, Math.max(0, Math.round(c.particleCount)));
  c.lineOpacity = Math.min(1, Math.max(0, c.lineOpacity));
  return c;
}
