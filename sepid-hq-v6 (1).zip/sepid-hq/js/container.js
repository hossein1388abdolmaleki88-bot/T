import * as THREE from '../vendor/three.module.js';
import { makeConfig } from './config.js';
import { ToothModel, Platform, Lighting, Camera, createBackdrop } from './scene-parts.js';
import { OrbitSystem } from './orbits.js';
import { AnimationController } from './controller.js';

export class Responsive3DContainer {
  constructor(element, options={}) {
    this.element=element;
    this.config=makeConfig(options);
    this.reduced=matchMedia('(prefers-reduced-motion: reduce)');
    this.mobile=matchMedia('(max-width: 600px)').matches;
    this.events=new AbortController();
    this.assetAbort=new AbortController();
    this.disposed=false;
    this.initialized=false;
    this.loading=false;
    this.visible=false;
    this.rect=null;
    this.lastQualityChange=0;
    this.canvas=document.createElement('canvas');
    this.canvas.className='tooth-webgl';
    this.canvas.setAttribute('aria-hidden','true');
    this.element.prepend(this.canvas);
    this.status=this.element.querySelector('[data-3d-status]');
    this.pauseButton=this.element.querySelector('[data-3d-pause]');
    this.resizeObserver=new ResizeObserver(()=>this.resize());
    this.resizeObserver.observe(this.element);
    this.visibilityObserver=new IntersectionObserver(entries=>{
      const entry=entries[0];
      this.visible=entry.isIntersecting;
      if(this.visible && !this.initialized && !this.loading) this.initialize();
      this.controller?.setVisible(this.visible);
    }, { rootMargin: '80px', threshold: .01 });
    this.visibilityObserver.observe(element);
    this.bindEvents();
  }

  async initialize() {
    if(this.disposed || this.loading) return;
    this.loading=true;
    this.setStatus('در حال آماده‌سازی صحنهٔ سه‌بعدی…');
    try {
      const config=this.config;
      this.renderer=new THREE.WebGLRenderer({
        canvas:this.canvas, antialias:true, alpha:true,
        powerPreference:'high-performance', stencil:false, depth:true
      });
      this.renderer.outputColorSpace=THREE.SRGBColorSpace;
      this.renderer.toneMapping=THREE.ACESFilmicToneMapping;
      this.renderer.toneMappingExposure=config.exposure;
      this.renderer.shadowMap.enabled=true;
      this.renderer.shadowMap.type=THREE.VSMShadowMap;
      this.renderer.shadowMap.autoUpdate=false;
      this.renderer.setClearColor(config.backgroundColor, config.transparentBackground ? 0 : 1);
      this.pixelLimit=this.qualityRatio(this.mobile);
      this.pixelRatio=this.pixelLimit;
      this.renderer.setPixelRatio(this.pixelRatio);
      this.scene=new THREE.Scene();
      this.camera=new Camera(config);
      this.lighting=new Lighting(this.scene,this.renderer,{...config, shadowMapSize:this.mobile ? Math.min(1024,config.shadowMapSize) : config.shadowMapSize});
      if (!config.transparentBackground) this.scene.add(createBackdrop(config));
      this.platform=await Platform.create(config);
      this.scene.add(this.platform);
      this.orbits=new OrbitSystem(config,this.mobile);
      this.scene.add(this.orbits);
      this.tooth=await ToothModel.create(config,this.assetAbort.signal);
      if(this.disposed) { this.tooth.traverse(node=>{node.geometry?.dispose();node.material?.dispose();});return; }
      if(this.mobile) this.tooth.mesh.material.transmission=0;
      this.scene.add(this.tooth);
      this.controller=new AnimationController({
        reduced:this.reduced, animate:config.autoAnimate,
        render:(time,dt,still)=>this.render(time,dt,still),
        adaptive:fps=>this.adapt(fps)
      });
      this.initialized=true;
      this.resize();
      this.controller.setVisible(this.visible);
      this.renderer.shadowMap.needsUpdate=true;
      this.setStatus('');
      this.element.classList.add('is-ready');
      if(this.pauseButton) this.pauseButton.hidden=false;
      this.updatePauseLabel();
      this.element.dispatchEvent(new CustomEvent('toothready',{detail:this}));
    } catch(error) {
      if(error.name!=='AbortError' && !this.disposed) {
        this.setStatus('نمایش سه‌بعدی در این مرورگر در دسترس نیست. WebGL را فعال کنید یا مرورگر را به‌روز کنید.');
        this.element.classList.add('webgl-unavailable');
        this.releaseGPU();
        if(this.config.debug) console.warn('Sepid 3D:',error);
      }
    } finally { this.loading=false; }
  }

  bindEvents() {
    const options={signal:this.events.signal};
    this.element.addEventListener('pointermove',event=>{
      if(!this.camera || this.reduced.matches || !this.rect) return;
      if(event.pointerType==='touch' && event.buttons===0) return;
      const x=(event.clientX-this.rect.left)/Math.max(1,this.rect.width)*2-1;
      const y=1-(event.clientY-this.rect.top)/Math.max(1,this.rect.height)*2;
      this.camera.goal.set(THREE.MathUtils.clamp(x,-1,1),THREE.MathUtils.clamp(y,-1,1));
      this.controller?.request();
    },{...options,passive:true});
    const reset=()=>{this.camera?.goal.set(0,0);this.controller?.request();};
    this.element.addEventListener('pointerleave',reset,options);
    this.element.addEventListener('pointerup',reset,options);
    this.element.addEventListener('pointercancel',reset,options);
    // No preventDefault or pointer capture: touch scrolling remains native.
    window.addEventListener('scroll',()=>{
      if(this.rect) this.rect.top=this.documentTop-window.scrollY;
    },{...options,passive:true});
    window.addEventListener('resize',()=>this.resize(),{...options,passive:true});
    document.addEventListener('visibilitychange',()=>{
      if(document.hidden) this.controller?.stop();else this.controller?.request();
    },options);
    this.reduced.addEventListener('change',()=>{
      this.controller?.request();this.updatePauseLabel();
    },options);
    this.pauseButton?.addEventListener('click',()=>{
      if(!this.controller) return;
      if(this.controller.userPaused) this.resume();else this.pause();
    },options);
    this.canvas.addEventListener('webglcontextlost',event=>{
      event.preventDefault();this.controller?.stop();
      this.setStatus('ارتباط با پردازندهٔ گرافیکی قطع شد؛ در انتظار بازیابی…');
    },options);
    this.canvas.addEventListener('webglcontextrestored',()=>{
      if(this.disposed)return;
      this.releaseGPU();this.initialized=false;
      this.initialize();
    },options);
  }

  qualityRatio(mobile) {
    // Supersample even a DPR=1 screen. Quality never drops below 2x CSS size.
    const desired=Math.max(mobile ? 2 : 2.5,(devicePixelRatio || 1)*1.25);
    return Math.min(desired,mobile ? this.config.mobilePixelRatio : this.config.maxPixelRatio);
  }

  resize() {
    const r=this.element.getBoundingClientRect();
    this.rect={left:r.left,top:r.top,width:r.width,height:r.height};
    this.documentTop=r.top+window.scrollY;
    if(!this.renderer || !this.camera || !r.width || !r.height) return;
    const mobileNow=matchMedia('(max-width: 600px)').matches;
    const limit=this.qualityRatio(mobileNow);
    if(limit!==this.pixelLimit) {
      this.pixelLimit=limit;
      this.pixelRatio=Math.max(this.config.minPixelRatio,Math.min(this.pixelRatio,limit));
      this.renderer.setPixelRatio(this.pixelRatio);
    }
    if(mobileNow!==this.mobile && this.tooth) {
      this.tooth.mesh.material.transmission=mobileNow ? 0 : this.config.translucency;
      this.tooth.mesh.material.needsUpdate=true;
    }
    this.mobile=mobileNow;
    this.renderer.setSize(r.width,r.height,false);
    this.camera.resize(r.width,r.height);
    this.controller?.request();
  }

  render(time,dt,still) {
    this.tooth.update(time,this.config,still);
    this.camera.update(dt,still);
    this.orbits.update(time,{reduced:this.reduced.matches,cameraDistance:this.camera.position.z});
    // Reuse the shadow map for tiny floating motion; refresh at a modest rate.
    const shadowStep=Math.floor(time*8);
    if(shadowStep!==this.shadowStep) {
      this.renderer.shadowMap.needsUpdate=true;
      this.shadowStep=shadowStep;
    }
    this.renderer.render(this.scene,this.camera);
    this.renderCount=(this.renderCount || 0)+1;
  }

  adapt(fps) {
    this.fps=fps;
    if(performance.now()-this.lastQualityChange<5000) return;
    let next=this.pixelRatio;
    if(fps<28) next=Math.max(this.config.minPixelRatio,this.pixelRatio-.1);
    else if(fps>57) next=Math.min(this.pixelLimit,this.pixelRatio+.1);
    if(Math.abs(next-this.pixelRatio)>.01) {
      this.pixelRatio=next;
      this.renderer.setPixelRatio(next);
      this.resize();
      this.lastQualityChange=performance.now();
    }
  }

  pause() { this.controller?.pause();this.updatePauseLabel(); }
  resume() { this.controller?.resume();this.updatePauseLabel(); }
  updatePauseLabel() {
    if(!this.pauseButton)return;
    this.pauseButton.disabled=this.reduced.matches;
    const paused=this.controller?.userPaused || this.reduced.matches;
    document.documentElement.dataset.sceneMotion=paused?'paused':'running';
    this.pauseButton.setAttribute('aria-pressed',String(!!paused));
    this.pauseButton.textContent=this.reduced.matches?'حرکت کاهش‌یافته':paused?'ادامهٔ حرکت':'توقف حرکت';
  }
  setStatus(message) { if(this.status){this.status.textContent=message;this.status.hidden=!message;} }
  getStats() {
    return {drawingBuffer:{width:this.canvas.width,height:this.canvas.height},antialias:!!this.renderer?.getContext().getContextAttributes().antialias,msaaSamples:this.renderer?.getContext().getParameter(this.renderer.getContext().SAMPLES),introProgress:this.orbits?.introProgress,introScale:this.orbits?.scale.x,ready:this.initialized,pixelRatio:this.pixelRatio,fps:this.fps || null,
      triangles:this.renderer?.info.render.triangles,drawCalls:this.renderer?.info.render.calls,
      renderedFrames:this.renderCount || 0,paused:!!this.controller?.userPaused,
      depthTest:this.orbits?.entries.every(item=>item.line.material.depthTest),
      vertexCount:this.tooth?.mesh.geometry.attributes.position.count};
  }
  releaseGPU() {
    this.controller?.dispose();
    this.scene?.traverse(node=>{
      node.geometry?.dispose();
      if(Array.isArray(node.material))node.material.forEach(material=>material.dispose());
      else { node.material?.map?.dispose(); node.material?.dispose(); }
    });
    this.lighting?.dispose();
    this.renderer?.dispose();
    this.scene=null;this.lighting=null;this.renderer=null;this.controller=null;
  }
  dispose() {
    if(this.disposed)return;
    this.disposed=true;
    this.assetAbort.abort();this.events.abort();
    this.resizeObserver.disconnect();this.visibilityObserver.disconnect();
    this.releaseGPU();this.canvas.remove();this.initialized=false;
  }
}
