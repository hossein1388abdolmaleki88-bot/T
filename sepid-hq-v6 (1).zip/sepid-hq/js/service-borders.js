// Resolution-independent champagne filaments following the actual rounded border.
// SVG is used only for UI decoration; the hero stays real WebGL geometry.
const ns='http://www.w3.org/2000/svg';
const cards=[...document.querySelectorAll('#services .service')];
const make=(tag,attrs={})=>{const n=document.createElementNS(ns,tag);for(const [k,v] of Object.entries(attrs))n.setAttribute(k,String(v));return n;};
const resize=new ResizeObserver(entries=>{
  for(const entry of entries){
    const card=entry.target,svg=card.querySelector('.service-border');
    if(!svg)continue;
    const w=card.offsetWidth,h=card.offsetHeight;
    svg.setAttribute('viewBox',`0 0 ${w} ${h}`);
    const radius=parseFloat(getComputedStyle(card).borderTopLeftRadius)||16;
    svg.querySelectorAll('rect').forEach(rect=>{
      rect.setAttribute('width',Math.max(0,w-3));rect.setAttribute('height',Math.max(0,h-3));rect.setAttribute('rx',radius-1);
    });
  }
});
const visible=new IntersectionObserver(entries=>{
  entries.forEach(entry=>entry.target.classList.toggle('border-visible',entry.isIntersecting));
},{rootMargin:'30px',threshold:0});
cards.forEach((card,index)=>{
  const svg=make('svg',{'class':'service-border','aria-hidden':'true',focusable:'false',preserveAspectRatio:'none'});
  const defs=make('defs');const id=`service-gold-${index}`;
  const gradient=make('linearGradient',{id,x1:'0%',y1:'0%',x2:'100%',y2:'75%'});
  for(const [offset,color] of [['0%','#8c7d61'],['24%','#dfcfaa'],['47%','#fff9e5'],['68%','#cbb581'],['100%','#a3977d']])gradient.append(make('stop',{offset,'stop-color':color}));
  defs.append(gradient);svg.append(defs);
  for(const [name,width,dash,opacity,offset] of [
    ['halo',5,'95 905',.24,0],
    ['tail',1.25,'170 830',.8,110],
    ['head',1.8,'58 942',1,0]
  ]){
    const rect=make('rect',{x:1.5,y:1.5,rx:15,fill:'none',pathLength:1000,
      stroke:name==='head'?'#f7e5b6':`url(#${id})`,'stroke-width':width,
      'stroke-dasharray':dash,'stroke-linecap':'round',opacity,
      class:`border-orbit border-${name}`});
    rect.style.setProperty('--edge-offset',`${offset}px`);
    rect.style.setProperty('--edge-duration',`${8.5+index*.65}s`);
    rect.style.setProperty('--edge-delay',`${-index*2.2}s`);
    svg.append(rect);
  }
  card.append(svg);resize.observe(card);visible.observe(card);
});
window.addEventListener('pagehide',event=>{if(!event.persisted){resize.disconnect();visible.disconnect();}},{once:true});
