export class AnimationController {
  constructor({ render, adaptive, reduced, animate=true }) {
    this.render=render;
    this.adaptive=adaptive;
    this.reduced=reduced;
    this.animate=animate;
    this.visible=true;
    this.userPaused=false;
    this.raf=0;
    this.last=0;
    this.time=0;
    this.sampleTime=0;
    this.samples=0;
    this.disposed=false;
    this.tick=this.tick.bind(this);
  }
  request() {
    if(!this.raf && !this.disposed && this.visible && !document.hidden) this.raf=requestAnimationFrame(this.tick);
  }
  tick(now) {
    this.raf=0;
    if(this.disposed || !this.visible || document.hidden) return;
    const rawDt=this.last ? (now-this.last)/1000 : 1/60;
    const dt=Math.min(rawDt,.05);
    this.last=now;
    const still=this.userPaused || this.reduced.matches || !this.animate;
    if(!still) this.time+=dt;
    this.render(this.time,dt,still);
    if(!still) {
      this.sampleTime+=rawDt;this.samples++;
      if(this.sampleTime>3) {
        this.adaptive(this.samples/this.sampleTime);
        this.sampleTime=0;this.samples=0;
      }
      this.request();
    } else this.last=0;
  }
  setVisible(value) { this.visible=value;if(value){this.last=0;this.request();}else this.stop(); }
  pause() { this.userPaused=true;this.request(); }
  resume() { this.userPaused=false;this.last=0;this.request(); }
  stop() { cancelAnimationFrame(this.raf);this.raf=0;this.last=0; }
  dispose() { this.disposed=true;this.stop(); }
}
