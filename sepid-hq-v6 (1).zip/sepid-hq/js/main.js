// Standard HTML/JS integration. Replace only the hero illustration, not the site.
const host=document.querySelector('[data-tooth-scene]');
if(host) {
  const observer=new IntersectionObserver(async entries=>{
    if(!entries.some(entry=>entry.isIntersecting))return;
    observer.disconnect();
    try {
      const { Responsive3DContainer }=await import('./container.js');
      window.sepidTooth=new Responsive3DContainer(host,window.SEPID_3D_OPTIONS || {});
    } catch(error) {
      const status=host.querySelector('[data-3d-status]');
      if(status)status.textContent='بارگذاری صحنه ممکن نشد. فایل‌ها را با یک وب‌سرور محلی باز کنید.';
      console.error('Could not load the local 3D module.',error);
    }
  },{rootMargin:'120px'});
  observer.observe(host);
}
