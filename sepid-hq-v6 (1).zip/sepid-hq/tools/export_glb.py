"""Optional portable GLB of the exact runtime mesh (no extra dependencies beyond numpy).
The browser uses tooth.bin to avoid shipping an additional glTF loader.
"""
from pathlib import Path
import json, struct
import numpy as np
root=Path(__file__).resolve().parents[1]
raw=(root/'assets/tooth.bin').read_bytes()
_,version,nv,ni=struct.unpack('<4sIII',raw[:16])
v=np.frombuffer(raw,dtype='<f4',count=nv*3,offset=16).reshape(-1,3)
f=np.frombuffer(raw,dtype='<u4',count=ni,offset=16+nv*12).reshape(-1,3)
normals=np.zeros_like(v)
face_normals=np.cross(v[f[:,1]]-v[f[:,0]],v[f[:,2]]-v[f[:,0]])
for i in range(3):np.add.at(normals,f[:,i],face_normals)
normals/=np.maximum(np.linalg.norm(normals,axis=1,keepdims=True),1e-9)
normal_file=root/'assets/tooth-normals.bin'
if normal_file.exists(): normals=np.frombuffer(normal_file.read_bytes(),dtype='<f4').reshape(-1,3)
chunks=[v.tobytes(),normals.astype('<f4').tobytes(),f.tobytes()]
offsets=[0,len(chunks[0]),len(chunks[0])+len(chunks[1])]
binary=b''.join(chunks)
material_color=[((int(h,16)/255+.055)/1.055)**2.4 for h in ['fa','fc','ff']]+[1]
gltf={
 'asset':{'version':'2.0','generator':'Sepid reference-based procedural tooth'},
 'scene':0,'scenes':[{'nodes':[0]}], 'nodes':[{'name':'ToothModel','mesh':0}],
 'meshes':[{'name':'Smooth enamel mesh','primitives':[{'attributes':{'POSITION':0,'NORMAL':1},'indices':2,'material':0}]}],
 'extensionsUsed':['KHR_materials_clearcoat'],
 'materials':[{'name':'Glossy white enamel','extensions':{'KHR_materials_clearcoat':{'clearcoatFactor':1,'clearcoatRoughnessFactor':.04}},'pbrMetallicRoughness':{'baseColorFactor':material_color,'metallicFactor':0,'roughnessFactor':.075}}],
 'buffers':[{'byteLength':len(binary)}],
 'bufferViews':[{'buffer':0,'byteOffset':offsets[i],'byteLength':len(chunks[i]),'target':34962 if i<2 else 34963} for i in range(3)],
 'accessors':[
  {'bufferView':0,'componentType':5126,'count':nv,'type':'VEC3','min':v.min(axis=0).tolist(),'max':v.max(axis=0).tolist()},
  {'bufferView':1,'componentType':5126,'count':nv,'type':'VEC3'},
  {'bufferView':2,'componentType':5125,'count':ni,'type':'SCALAR'}
 ]
}
metadata=json.dumps(gltf,separators=(',',':')).encode()
metadata+=b' '*((-len(metadata))%4)
binary+=b'\0'*((-len(binary))%4)
body=struct.pack('<II',len(metadata),0x4E4F534A)+metadata+struct.pack('<II',len(binary),0x004E4942)+binary
(root/'assets/tooth.glb').write_bytes(struct.pack('<III',0x46546C67,2,12+len(body))+body)
print('Exported assets/tooth.glb')
