"""Deterministic seamless mineral texture for the actual 3D plinth (not a rendered scene)."""
from pathlib import Path
import numpy as np
from scipy.ndimage import gaussian_filter
from PIL import Image
rng=np.random.default_rng(41)
n=512
noise=rng.normal(size=(n,n))
def cloud(sigma):
    x=gaussian_filter(noise,sigma,mode='wrap')
    return x/(x.std()+1e-9)
field=.5*cloud(22)+.27*cloud(8)+.16*cloud(2.5)+.07*cloud(.7)
veins=np.exp(-((cloud(14)+.25*cloud(3)-.25)/.095)**2)
mineral=.87+.045*field-.09*veins+.015*cloud(.55)
mineral=np.clip(mineral,.63,.99)
color=np.stack([mineral*.94,mineral*.975,mineral],axis=-1)
p=Path(__file__).resolve().parents[1]/'assets'/'ice-marble.jpg'
Image.fromarray(np.uint8(np.clip(color,0,1)*255)).save(p,quality=94)
print(p)
