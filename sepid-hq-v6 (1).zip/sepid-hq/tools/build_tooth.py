"""Reference-fitted, closed 3D tooth mesh.

The silhouette is a hand-traced cubic outline from reference #1 (pixel coordinates).
It is inflated into a smooth, thick, closed 3D enamel surface, NOT a plane/texture.
A signed-distance profile controls rounded edges; crown/root thickness varies in 3D.
Requires numpy, scipy and scikit-image. Build-time only.
"""
from pathlib import Path
import json
import struct
import numpy as np
from scipy.ndimage import gaussian_filter
from scipy.sparse import coo_matrix
from skimage.measure import marching_cubes

ROOT = Path(__file__).resolve().parents[1]
STEP = .016
SCALE = .0215
CENTER = np.array([258., 143.])

# Consecutive cubic Bezier handles/endpoints; their coordinates refer to image #1.
# The open root bifurcation is deliberately asymmetrical, as in the reference.
start = [236, 75]
segments = [
    [[223, 73], [215, 80], [211, 90]],
    [[206, 101], [207, 115], [211, 126]],
    [[215, 136], [217, 140], [217, 151]],
    [[216, 168], [218, 185], [224, 197]],
    [[228, 205], [233, 211], [237, 210]],
    [[242, 209], [246, 197], [248, 184]],
    [[250, 170], [252, 158], [257, 153]],
    [[259, 150], [263, 155], [266, 162]],
    [[270, 173], [270, 191], [272, 203]],
    [[273, 211], [277, 212], [282, 206]],
    [[292, 194], [297, 174], [298, 153]],
    [[299, 141], [301, 133], [304, 123]],
    [[309, 110], [309, 98], [304, 88]],
    [[301, 80], [294, 75], [285, 75]],
    [[275, 75], [271, 80], [262, 81]],
    [[252, 82], [246, 77], [236, 75]]
]
points = []
p0 = np.array(start, dtype=float)
for control in segments:
    p1, p2, p3 = np.array(control, dtype=float)
    t = np.linspace(0, 1, 60, endpoint=False)[:, None]
    curve = (1-t)**3*p0 + 3*(1-t)**2*t*p1 + 3*(1-t)*t*t*p2 + t**3*p3
    points.extend(curve.tolist())
    p0 = p3
points = np.asarray(points)
world = (points - CENTER) * np.array([SCALE, -SCALE])

lo = np.array([-1.4, -1.8, -.8])
hi = np.array([1.4, 1.8, .8])
axes = [np.arange(a, b + STEP, STEP, dtype=np.float32) for a, b in zip(lo, hi)]
nx, ny, nz = map(len, axes)
# Analytic sub-pixel distance to the Bezier-sampled outline.
# Never derive shading from a low-resolution raster mask: that causes banding.
X, Y = np.meshgrid(axes[0], axes[1], indexing='ij')
minimum_sq = np.full(X.shape, np.inf)
inside = np.zeros(X.shape, dtype=bool)
for a, b in zip(world, np.roll(world, -1, axis=0)):
    vx, vy = b-a
    length_sq = vx*vx+vy*vy
    t = np.clip(((X-a[0])*vx+(Y-a[1])*vy)/max(length_sq,1e-16),0,1)
    minimum_sq = np.minimum(minimum_sq,(X-a[0]-t*vx)**2+(Y-a[1]-t*vy)**2)
    if abs(vy)>1e-14:
        crossing = ((a[1]>Y)!=(b[1]>Y)) & (X < vx*(Y-a[1])/vy+a[0])
        inside ^= crossing
signed = np.sqrt(minimum_sq)*np.where(inside,1,-1)
signed = gaussian_filter(signed, .04 / STEP)
Z = axes[2][None, None, :]

# Full 3D volume: rounded edge rolloff, fuller crown, progressively thinner roots.
t = np.clip((Y+.35)/1.55, 0, 1)
crown = t*t*(3-2*t)
depth = .36 + .22*crown
# Very restrained crown-lobe variation; no grooves, lesions or decoration.
depth *= 1 + .018*np.exp(-((X+.44)/.40)**2-((Y-.73)/.6)**2)
center_z = .017*np.tanh(X/.6)*crown
rounding = .155 + .035*crown
inflation = 1-np.exp(np.clip(-signed/rounding, -14, 14))
field = ((Z-center_z[:,:,None])/depth[:,:,None])**2-inflation[:,:,None]
vertices, faces, _, _ = marching_cubes(field, level=0, spacing=(STEP,)*3, allow_degenerate=False)
vertices += lo
faces = faces.astype(np.uint32)

# Taubin surface smoothing reduces sampling artefacts without inflating/shrinking.
edges = np.concatenate([faces[:,[0,1]],faces[:,[1,2]],faces[:,[2,0]]])
edges = np.concatenate([edges, edges[:,::-1]])
adj = coo_matrix((np.ones(len(edges)),(edges[:,0],edges[:,1])),shape=(len(vertices),len(vertices))).tocsr()
adj.data[:] = 1
weights = np.asarray(adj.sum(axis=1)).reshape(-1,1)
for _ in range(12):
    for factor in [.42, -.43]:
        vertices += factor*(adj @ vertices/weights-vertices)

a,b,c=vertices[faces[:,0]],vertices[faces[:,1]],vertices[faces[:,2]]
volume=np.einsum('ij,ij->i',a,np.cross(b,c)).sum()/6
if volume<0: faces=faces[:,[0,2,1]]
vertices=vertices.astype('<f4')
faces=faces.astype('<u4')
output=ROOT/'assets/tooth.bin'
output.write_bytes(struct.pack('<4sIII',b'TOTH',1,len(vertices),len(faces)*3)+vertices.tobytes()+faces.tobytes())
profile={'source':'Reference 1 from user repository Pp','start':start,'segments':segments,'pixelCenter':CENTER.tolist(),'worldScale':SCALE}
(ROOT/'tools/reference-profile.json').write_text(json.dumps(profile,indent=2))
print(f'{len(vertices):,} vertices; {len(faces):,} triangles; {output.stat().st_size:,} bytes')
print('bounds',vertices.min(axis=0),vertices.max(axis=0))

# Smooth area-weighted shading normals separately from the silhouette.
# This suppresses marching-cubes triangulation noise in glossy reflections.
normals = np.zeros_like(vertices)
tri = vertices[faces]
fn = np.cross(tri[:,1]-tri[:,0], tri[:,2]-tri[:,0])
for corner in range(3): np.add.at(normals,faces[:,corner],fn)
normals /= np.maximum(np.linalg.norm(normals,axis=1,keepdims=True),1e-12)
for _ in range(8):
    normals = normals*.55 + (adj @ normals/weights)*.45
    normals /= np.maximum(np.linalg.norm(normals,axis=1,keepdims=True),1e-12)
(ROOT/'assets/tooth-normals.bin').write_bytes(normals.astype('<f4').tobytes())
